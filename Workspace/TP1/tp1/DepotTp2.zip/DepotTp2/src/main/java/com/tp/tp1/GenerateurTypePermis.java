package com.tp.tp1;

public class GenerateurTypePermis {
    private final static short MAX_AGE_ENFANT = 16;

    //Il y a seulement 2 type de permis : enfant et adulte inutile d'en avoir 4.
    public static String genererTypePermis(int age){
        String typePermis = "Adulte";
        if(age <= MAX_AGE_ENFANT) {
            typePermis = "Enfant";
        }
        return typePermis;
    }
}
