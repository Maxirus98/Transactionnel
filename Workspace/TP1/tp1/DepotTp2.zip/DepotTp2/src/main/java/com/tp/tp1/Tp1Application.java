package com.tp.tp1;

import com.tp.tp1.services.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp1Application implements CommandLineRunner {
    @Autowired
    SystemService service;
    public static void main(String[] args) {
        SpringApplication.run(Tp1Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        service.envoyerCourriel("dupuismaxime@hotmail.com", "Test email", "Message");
    }
}
