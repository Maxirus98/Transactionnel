package com.tp.tp1.models;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Data
public class PermisTest extends Permis{
    @NotNull
    private LocalDate dateExpiration;

    public PermisTest() {
       dateExpiration = LocalDate.now().plusDays(15);
    }
}
