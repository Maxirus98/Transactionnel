package com.tp.tp1.services;

import com.tp.tp1.models.PermisTest;
import com.tp.tp1.repository.PermisRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
@Service
public class PermisService {
    @Autowired
    private PermisRepository permisRepository;
    public boolean permisExiste(String input1, String input2){
        return permisRepository.findPermisByCitoyen_CourrielAndCitoyen_Mdp(input1, input2) != null;
    }

    public boolean permisActif(String input1, String input2){
        return permisRepository.findPermisTestByCitoyen_CourrielAndCitoyen_Mdp(input1, input2).getDateExpiration().isAfter(LocalDate.now());
    }

    public boolean supprimerPermisParCourrielEtMdpDeCitoyen(String input1, String input2){
        return permisRepository.deletePermisByCitoyen_CourrielAndCitoyen_Mdp(input1, input2) == 1;
    }

    public void renouvellerPermisTest(String input1, String input2){
        PermisTest permisTest = permisRepository.findPermisTestByCitoyen_CourrielAndCitoyen_Mdp(input1, input2);
        if(permisActif(input1, input2)){
            permisTest.setDateDistribution(LocalDate.now());
            permisTest.setDateExpiration(permisTest.getDateDistribution().plusDays(15));
        }
    }
}
