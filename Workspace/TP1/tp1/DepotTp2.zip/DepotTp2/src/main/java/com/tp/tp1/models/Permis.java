package com.tp.tp1.models;

import lombok.Builder;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Data
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(discriminatorType = DiscriminatorType.STRING)
public class Permis {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idPermis;
    @NotNull
    private String typePermis; //VA AVEC L'AGE DE L'UTILISATEUR
    @NotNull
    private LocalDate dateDistribution;

    @OneToOne(targetEntity = Citoyen.class, cascade=CascadeType.ALL)
    private Citoyen citoyen;

    public Permis() {
        dateDistribution = LocalDate.now();
    }
}
