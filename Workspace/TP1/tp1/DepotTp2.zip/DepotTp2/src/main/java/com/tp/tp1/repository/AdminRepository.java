package com.tp.tp1.repository;

import com.tp.tp1.models.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//Dire que cette interface est un repository
@Repository
public interface AdminRepository extends JpaRepository<Admin, Integer> {
}
