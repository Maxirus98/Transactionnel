package com.tp.tp1.repository;

import com.tp.tp1.models.Admin;
import com.tp.tp1.models.Citoyen;

import com.tp.tp1.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<Citoyen, Integer> {
    public Citoyen findCitoyenByCourrielAndMdp(String input1, String input2);
    public Integer deleteCitoyenByCourrielAndMdp(String input1, String input);
}
