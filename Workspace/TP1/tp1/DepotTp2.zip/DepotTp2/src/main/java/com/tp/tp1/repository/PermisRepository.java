package com.tp.tp1.repository;

import com.tp.tp1.models.Permis;
import com.tp.tp1.models.PermisTest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PermisRepository extends JpaRepository<Permis, Integer> {
    public Permis findPermisByCitoyen_CourrielAndCitoyen_Mdp(String input1, String input2);
    public Integer deletePermisByCitoyen_CourrielAndCitoyen_Mdp(String input1, String input2);
    public PermisTest findPermisTestByCitoyen_CourrielAndCitoyen_Mdp(String input1, String input2);
}
