package com.tp.tp1;

import com.tp.tp1.models.Citoyen;
import com.tp.tp1.models.Permis;
import com.tp.tp1.models.PermisTest;
import com.tp.tp1.models.User;
import com.tp.tp1.repository.PermisRepository;
import com.tp.tp1.repository.UserRepository;
import com.tp.tp1.services.SystemService;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.File;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.*;

@DataJpaTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)//POUR BYPASS LE STATIC
@ComponentScan(basePackages = {"com.tp.tp1.services"})
public class UseCasesTests {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PermisRepository permisRepository;

    @BeforeAll
    public void insererDonnees(){
        Citoyen citoyen1 = new Citoyen();
        //Permis Vaccin
        Permis permis1 = new Permis();

        citoyen1.setCourriel("dupuismaxime@hotmail.com");citoyen1.setVille("Montréal");citoyen1.setNom("Dupuis");
        citoyen1.setPrenom("Maxime");citoyen1.setAge(12);citoyen1.setTelephone("514-111-2222");citoyen1.setSexe('M');
        citoyen1.setMdp("mdp");
        //Choisi le typePermis automatiquement en fonction de l'âge.
        permis1.setTypePermis(GenerateurTypePermis.genererTypePermis(citoyen1.getAge()));
        permis1.setCitoyen(citoyen1);


        Citoyen citoyen2 = new Citoyen();
        PermisTest permis2 = new PermisTest();

        citoyen2.setCourriel("dm@hotmail.com");citoyen2.setVille("Montréal");citoyen2.setNom("Doré");
        citoyen2.setPrenom("Mathieu");citoyen2.setAge(22);citoyen2.setTelephone("514-222-1111");citoyen2.setSexe('F');
        citoyen2.setMdp("motdepasse");
        permis2.setTypePermis(GenerateurTypePermis.genererTypePermis(citoyen2.getAge()));
        permis2.setCitoyen(citoyen2);


        permisRepository.saveAll(Arrays.asList(permis1, permis2));
        userRepository.saveAll(Arrays.asList(citoyen1, citoyen2));
    }

    @Test
    @Disabled
    public void trouverTousUtilisateurs(){
        assertEquals(2, userRepository.findAll().size());
    }
    @Test
    @Disabled
    public void trouverUtilisateurParCourrielEtMdp(){
        assertEquals("Dupuis", userRepository.findCitoyenByCourrielAndMdp("dupuismaxime@hotmail.com", "mdp").getNom());
    }
    @Test
    @Disabled
    public void trouverTousPermis(){
        assertEquals(2, permisRepository.findAll().size());
    }

    @Test
    @Disabled
    public void supprimerCitoyenParCourrielEtMdp(){
        assertEquals(1, userRepository.deleteCitoyenByCourrielAndMdp("dm@hotmail.com", "motdepasse"));
    }

    @Test
    @Disabled
    public void supprimerPermisParCourrielEtMdpDeCitoyen(){
        assertEquals(1, permisRepository.deletePermisByCitoyen_CourrielAndCitoyen_Mdp("dm@hotmail.com", "motdepasse"));
    }

    @Test
    @Disabled
    public void verifierSiPermisActif(){
        assertTrue(permisRepository.findPermisTestByCitoyen_CourrielAndCitoyen_Mdp("dm@hotmail.com", "motdepasse").getDateExpiration().isAfter(LocalDate.now()));
    }
    @Test
    public void connecter(){
        //besoin du ministere
    }
    @Test
    public void inscrire(){
        //besoin du ministere
    }
    //Not TDD
    @Test
    @Disabled
    public void genererPermisVaccin(){
        //Generer pdf et image, donc vérifier que les fichiers ont été crée
        assumeTrue(SystemService.genererQR(permisRepository.findPermisByCitoyen_CourrielAndCitoyen_Mdp("dupuismaxime@hotmail.com","mdp").toString(), "./nouveauQr.QR"));
        assertTrue(SystemService.genererPDF("./nouveauQr.pdf", "./nouveauQr.QR"));
    }

    //Not TDD
    @Test
    @Disabled
    public void genererPermisTest(){
        assumeTrue(SystemService.genererQR(permisRepository.findPermisTestByCitoyen_CourrielAndCitoyen_Mdp("dm@hotmail.com","motdepasse").toString(), "./nouveauQr.QR"));
        assertTrue(SystemService.genererPDF("./nouveauQr.pdf", "./nouveauQr.QR"));
    }

    //Not TDD
    @Test
    @Disabled
    public void renouvellerPermisTest(){
        //Vérifier si permis existe deja
        assertEquals("Doré", permisRepository.findPermisTestByCitoyen_CourrielAndCitoyen_Mdp("dm@hotmail.com", "motdepasse").getCitoyen().getNom());
        //Set la date à une date expiré du permis.
        permisRepository.findPermisTestByCitoyen_CourrielAndCitoyen_Mdp("dm@hotmail.com", "motdepasse").setDateExpiration(LocalDate.now());
        //Verifier que permis expiré
        assertFalse(permisRepository.findPermisTestByCitoyen_CourrielAndCitoyen_Mdp("dm@hotmail.com", "motdepasse").getDateExpiration().isAfter(LocalDate.now()));
        //Generer pdf et image
        assumeTrue(SystemService.genererQR(permisRepository.findPermisTestByCitoyen_CourrielAndCitoyen_Mdp("dm@hotmail.com","motdepasse").toString(), "./nouveauQr.QR"));
        assertTrue(SystemService.genererPDF("./nouveauQr.pdf", "./nouveauQr.QR"));
    }
}
