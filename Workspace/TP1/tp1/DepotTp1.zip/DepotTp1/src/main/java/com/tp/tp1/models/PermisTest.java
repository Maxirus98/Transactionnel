package com.tp.tp1.models;

import lombok.Data;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;

@Entity
@Data
public class PermisTest extends Permis{
    @NotNull
    private String dateExpiration;
}
