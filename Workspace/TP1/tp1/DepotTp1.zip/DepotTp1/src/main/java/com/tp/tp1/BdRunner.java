package com.tp.tp1;

import com.tp.tp1.models.*;
import com.tp.tp1.repository.PermisRepository;
import com.tp.tp1.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Component
public class BdRunner implements CommandLineRunner {
    @Autowired
    PermisRepository permisRepository;
    @Autowired
    UserRepository repository;

    private void insert() {
        Admin u = new Admin();
        u.setCourriel("admin@admin.com"); u.setMdp("toto1234"); u.setPrenom("Jonathan");
        u.setNom("Bertrand"); u.setRole("Strategy Designer");

        Citoyen u1 = new Citoyen();
        u1.setCourriel("citoyen@citoyen.com"); u1.setMdp("pwd1234");
        u1.setTelephone("514-111-2222"); u1.setAge(22); u1.setSexe('M');
        u1.setPrenom("Maxime"); u1.setNom("Dupuis"); u1.setVille("Montreal");

        Permis p1 = new Permis(); p1.setTypePermis("Tuteur");
        p1.setActif(true);
        p1.setDate_distribution("2021-02-24");
        p1.setCitoyen(u1);

        Citoyen u2 = new Citoyen();
        u2.setCourriel("citoyen2@citoyen.com"); u1.setMdp("mdp1234");
        u2.setTelephone("514-222-1111"); u1.setAge(17); u1.setSexe('F');
        u2.setPrenom("Sylvie"); u1.setNom("Proulx"); u1.setVille("Ottawa");
        u2.setNoReference(1);

        PermisTest p2 = new PermisTest();
        p2.setTypePermis("Enfant");
        p2.setActif(true);
        p2.setDate_distribution("2021-02-28");
        p2.setDateExpiration("2021-03-14");
        p2.setCitoyen(u2);

        List<User> userData = new ArrayList<>();
        userData.add(u);
        userData.add(u1);
        this.repository.saveAll(userData);

        List<Permis> permisData = new ArrayList<>();
        permisData.add(p1);
        permisData.add(p2);
        this.permisRepository.saveAll(permisData);

    }

    private void cleanData(){
        this.repository.deleteAll();
        this.permisRepository.deleteAll();
    }

    @Override
    public void run(String... args) throws Exception {
        cleanData();
        insert();
    }
}
