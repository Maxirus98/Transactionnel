package com.tp.tp1.models;

import lombok.Builder;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Data
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(discriminatorType = DiscriminatorType.STRING)
public class Permis {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idPermis;
    @NotNull
    private String typePermis;
    @NotNull
    private String date_distribution;
    private boolean actif;

    @OneToOne(targetEntity = Citoyen.class)
    @JoinColumn(name = "id_user")
    private transient Citoyen citoyen;
}
