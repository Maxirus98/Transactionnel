package com.tp.tp1.models;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@Data
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idUser;
    @NotNull
    private String courriel;
    @NotNull
    private String mdp;
    @NotNull
    private String nom;
    @NotNull
    private String prenom;


}
