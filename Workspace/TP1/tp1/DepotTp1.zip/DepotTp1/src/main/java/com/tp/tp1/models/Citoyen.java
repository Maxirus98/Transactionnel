package com.tp.tp1.models;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
@Data
public class Citoyen extends User{
    @NotNull
    private char sexe;
    @NotNull
    private int age;
    @NotNull
    private String telephone;
    @NotNull
    private String ville;
    @NotNull
    private int noReference;
}
