package com.tp.tp1.repository;

import com.tp.tp1.models.Admin;
import com.tp.tp1.models.Citoyen;

import com.tp.tp1.models.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Integer> {
    public User findUserByCourrielAndMdp(String input1, String input2);
}
