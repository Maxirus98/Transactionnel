package com.tp.tp1.repository;

import com.tp.tp1.models.Permis;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PermisRepository extends JpaRepository<Permis, Integer> {
    public Permis findPermisByIdPermis(int id);
    public boolean deletePermisByIdPermis(int id);

}
